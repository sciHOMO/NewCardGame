#include "../GamePlay/CardPlayer.h"
#include "../CardCoreSystem/CardCoreDriver.h"
#include "../Client/EventListener.h"
#include "GameFramework/PlayerState.h"
#include "Camera/CameraActor.h"
#include "../SaveGame/LocalDeckSettings.h"
#include "ENITAS/Client/CardModel.h"
#include "ENITAS/Misc/MiscFunctionLibrary.h"
#include "Kismet/GameplayStatics.h"

void ACardPlayer::BeginPlay()
{
	Super::BeginPlay();
	
	if (GetNetMode() != NM_DedicatedServer)
	{
		SetLocalElement();	//准备本地元素
		
		EventListener = NewObject<UEventListener>(this, EventListenerClass);
		EventListener -> RegisterComponent();	//创建事件聆听器
		EventListener -> Controller = this;
	}
}

void ACardPlayer::Tick(float DeltaSeconds)
{
	if (EventListener)
	{
		EventListener -> CheckQueue();
	}
}

//****************************本地前置效果*******************************	
void ACardPlayer::SetLocalElement()
{
	if (PlayerState && PlayerState -> GetPlayerId() != INT_ERROR)
	{
		SetViewTarget(UGameplayStatics::GetActorOfClass(this, ACameraActor::StaticClass()));	//摄像机绑定
	}
	else
	{
		FTimerHandle TimerHandle;
		GetWorldTimerManager() . SetTimer(TimerHandle, this, &ACardPlayer::SetLocalElement, 0.1F);
	}
}

void ACardPlayer::FindLocalDeck()
{
	if (const USaveGame* LocalDeck = UGameplayStatics::LoadGameFromSlot(TEXT("LocalDeckSettings"), 0))
	{
		if (const ULocalDeckSettings* FoundLocalDeck = Cast<ULocalDeckSettings>(LocalDeck))
		{
			SendLocalDeck(FoundLocalDeck -> FindDeckByIndex(1));
		}
	}
}

void ACardPlayer::SendLocalDeck_Implementation(const TArray<int>& Deck)
{
	if (PlayerState && PlayerState -> GetPlayerId() != INT_ERROR)
	{
		Cast<ACardCoreDriver>(GetWorld() -> GetGameState()) -> CallBackForDeck(PlayerState -> GetPlayerId(), Deck);	//复制牌组
	}
}
//*************************************************************************

//***************************客户端行动请求*******************************
void ACardPlayer::RequestEndTurn_Implementation()
{
	if(GetWorld() -> GetGameState() && GetNetMode() != NM_Client)
	{
		Cast<ACardCoreDriver>(GetWorld() ->  GetGameState()) -> ReceiveEndTurn(PlayerState -> GetPlayerId());
	}
}

void ACardPlayer::RequestPlayCard_Implementation(const int SourceCard, const int TargetCard, const TArray<int>& Sacrifice)
{
	if(GetWorld() -> GetGameState() && GetNetMode() != NM_Client)
	{
		Cast<ACardCoreDriver>(GetWorld() ->  GetGameState())  -> ReceivePlayCard(PlayerState -> GetPlayerId(), SourceCard, TargetCard, Sacrifice);
	}
}

void ACardPlayer::RequestAttack_Implementation(const int SourceCard, const int TargetCard)
{
	if(GetWorld() -> GetGameState() && GetNetMode() != NM_Client)
	{
		Cast<ACardCoreDriver>(GetWorld() ->  GetGameState()) -> ReceiveAttack(PlayerState -> GetPlayerId(), SourceCard, TargetCard);
	}
}

void ACardPlayer::RequestActivate_Implementation(const int Card, const TArray<int>& Sacrifice)
{
	if(GetWorld() -> GetGameState() && GetNetMode() != NM_Client)
	{
		Cast<ACardCoreDriver>(GetWorld() ->  GetGameState()) -> ReceiveActivate(PlayerState -> GetPlayerId(), Card, Sacrifice);
	}
}

void ACardPlayer::RequestTarget_Implementation(const int PickedTarget)
{
	if(GetWorld() -> GetGameState() && GetNetMode() != NM_Client)
	{
		Cast<ACardCoreDriver>(GetWorld() ->  GetGameState()) -> ReceiveTarget(PlayerState -> GetPlayerId(), PickedTarget);
	}
}
//*************************************************************************

void ACardPlayer::LeftMouseButtonClicked()
{
	AActor* HitActor = nullptr;
	UMiscFunctionLibrary::GetMouseOverActor(this, HitActor);
	if (!HitActor || !Cast<ACardModel>(HitActor)) return;
	
	FocusActor = Cast<ACardModel>(HitActor);
	if (FocusActor -> CardStruct.CardZone == EZone::HandZone && FocusActor -> CardStruct.PlayerIndex == PlayerState -> GetPlayerId())
	{
		InputMode = EInputMode::PlayCard;
		FocusActor -> StartFollow();
	}
	if (FocusActor -> CardStruct.CardZone == EZone::BoardZone && FocusActor -> CardStruct.PlayerIndex == PlayerState -> GetPlayerId())
	{
		InputMode = EInputMode::Attack;
		FocusActor -> StartKeepFocus();
	}
}

void ACardPlayer::LeftMouseButtonReleased()
{
	if (!FocusActor) return;
	FHitResult HitResult;
	
	GetHitResultUnderCursor(ECollisionChannel::ECC_GameTraceChannel1, true, HitResult);
	if (FocusActor && InputMode == EInputMode::PlayCard)
	{
		if (HitResult.bBlockingHit)
		{
			RequestPlayCard(FocusActor -> CardStruct.CardIndex, INT_ERROR, {});
			FocusActor -> SetActorHiddenInGame(true);
			FocusActor -> SetActorEnableCollision(false);
			FocusActor = nullptr;
			//进入询问祭品界面
		}
		else
		{
			FocusActor -> EndFollow();
		}
		return;
	}
	
	GetHitResultUnderCursor(ECollisionChannel::ECC_Visibility, true, HitResult);
	if (FocusActor && InputMode == EInputMode::Attack)
	{
		SecondFocusActor = Cast<ACardModel>(HitResult.GetActor());
		if (SecondFocusActor)
		{
			RequestAttack(FocusActor -> CardStruct.CardIndex, SecondFocusActor -> CardStruct.CardIndex);
			FocusActor -> EndKeepFocus();
			FocusActor = nullptr;
			SecondFocusActor = nullptr;
			//进入攻击流程
		}
		else
		{
			FocusActor -> EndKeepFocus();
		}
	}
}

bool ACardPlayer::CanEndTurn()
{
	return false;
}

bool ACardPlayer::CanPlayCard(const int SourceCard, const int TargetCard, const TArray<int>& Sacrifice)
{
	return false;
}

bool ACardPlayer::CanAttack(const int SourceCard, const int TargetCard)
{
	return false;
}

bool ACardPlayer::CanActivate(const int Card, const TArray<int>& Sacrifice)
{
	return false;
}
