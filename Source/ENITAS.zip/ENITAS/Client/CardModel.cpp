#include "../Client/CardModel.h"

#include "EventListener.h"
#include "../Misc/MiscFunctionLibrary.h"
#include "ENITAS/GamePlay/CardPlayer.h"

ACardModel::ACardModel()
{
	PrimaryActorTick.bCanEverTick = true;
	Root = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Root"));
	RootComponent = Root;
	CardCollision = CreateDefaultSubobject<UBoxComponent>(TEXT("CardCollision"));
	CardCollision -> SetupAttachment(Root);
	CardMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CardMesh"));
	CardMesh -> SetupAttachment(Root);
}

void ACardModel::BeginPlay()
{
	Super::BeginPlay();
	
}

void ACardModel::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (CardState == EState::Lerp)
	{
		LerpToTargetLocation(12.0F);
	}
	if (CardState == EState::Follow)
	{
		UMiscFunctionLibrary::GetMouseProjectileLocationAtHeight(Cast<APlayerController>(EventListener -> Controller), 240.0F, TargetLocation);
		LerpToTargetLocation(25.0F);
	}
}

void ACardModel::LerpToTargetLocation(const float LerpSpeed)
{
	const FVector CurrentLocation = GetActorLocation();
	const FVector CurrenScale = GetActorScale3D();
	const FVector NextLocation = FMath::VInterpTo(CurrentLocation, TargetLocation, GetWorld() -> DeltaTimeSeconds, LerpSpeed);
	const FVector NextScale = FMath::Lerp(CurrenScale, FVector::OneVector, 0.2f);
	SetActorLocation(NextLocation);
	SetActorScale3D(NextScale);

	const FVector CurrentAdditiveLocation = CardMesh -> GetRelativeLocation();
	const FVector NextAdditiveLocation = FMath::VInterpTo(CurrentAdditiveLocation, AdditiveLocation, GetWorld() -> DeltaTimeSeconds, 12.0F);
	CardMesh -> SetRelativeLocation(NextAdditiveLocation);
}

void ACardModel::StartDrawCard_Implementation(const bool Owning, const FEventPackageStruct& Package)
{
	PackageStruct = Package;
}

void ACardModel::EndDrawCard()
{
	EventListener -> AddToHandZone(this);
	EventListener -> RefreshHandZone(CardStruct.PlayerIndex);
	EventListener -> Clear(PackageStruct.GlobalEventIndex);
	CardState = EState::Lerp;
}

void ACardModel::StartSummonServant_Implementation(const bool Owning, const FEventPackageStruct& Package)
{
	PackageStruct = Package;
}

void ACardModel::EndSummonServant()
{
	CardState = EState::Lerp;
}

void ACardModel::StartFocus()
{
	if (CardStruct.CardZone == EZone::HandZone)
	{
		AdditiveLocation = FVector(0.0F, 30.0f, 30.0F);
	}
	if (CardStruct.CardZone == EZone::BoardZone)
	{
		AdditiveLocation = FVector(0.0F, 0.0f, 30.0F);
	}
}

void ACardModel::EndFocus()
{
	if (!KeepFocus)
	{
		EndKeepFocus();
	}
}

void ACardModel::StartKeepFocus()
{
	KeepFocus = true;
	StartFocus();
}

void ACardModel::EndKeepFocus()
{
	AdditiveLocation = FVector::ZeroVector;
	KeepFocus = false;
}

void ACardModel::StartFollow()
{
	EventListener -> RemoveFromHandZone(this);
	EventListener -> RefreshHandZone(CardStruct.PlayerIndex);
	CardState = EState::Follow;
}

void ACardModel::EndFollow()
{
	EventListener -> AddToHandZone(this);
	EventListener -> RefreshHandZone(CardStruct.PlayerIndex);
	CardState = EState::Lerp;
}


