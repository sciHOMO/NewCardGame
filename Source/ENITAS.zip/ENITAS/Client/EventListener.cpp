#include "../Client/EventListener.h"
#include "../CardCoreSystem/EventPackage.h"
#include "AIController.h"
#include "CardModel.h"

UEventListener::UEventListener()
{

}

//****************************本地效果接收********************************
void UEventListener::ListenEventPackageSync(const FEventPackageStruct& Package)
{
	Enqueue(Package);
}

void UEventListener::ListenEventPackageAsync(const FEventPackageStruct& Package)
{
	
}

void UEventListener::Enqueue(const FEventPackageStruct& Package)
{
	if (Package.GlobalEventIndex < LocalEventIndex) return;	//去重、排序
	if (PendingQueue.ContainsByPredicate([&](const FEventPackageStruct& FoundPackage) { return FoundPackage.GlobalEventIndex == Package.GlobalEventIndex; })) return;
	const int32 Index = Algo::LowerBound(PendingQueue, Package.GlobalEventIndex,[](const FEventPackageStruct& FoundPackage, const int64 Value) { return FoundPackage.GlobalEventIndex < Value;});
	PendingQueue.Insert(Package, Index);	//二分法插入
}

void UEventListener::CheckQueue()
{
	if (!PendingQueue.IsEmpty() && !ProcessingPackage.IsValid() && FindPackageByIndex(LocalEventIndex) && FindPackageByIndex(LocalEventIndex) -> IsValid() && !Cast<AAIController>(GetOwner()))	//不为机器人生成效果
	{
		ProcessingPackage = *FindPackageByIndex(LocalEventIndex);
		Execute(ProcessingPackage);
	}
}

void UEventListener::Execute(const FEventPackageStruct& Package)
{
	switch (Package.PackageType)
	{
		case EPackageType::GameStart:					HandleGameStart(Package);					break;
		case EPackageType::GameEnd:					HandleGameEnd(Package);					break;
		case EPackageType::TurnStart:					HandleTurnStart(Package);						break;
		case EPackageType::TurnEnd:						HandleTurnEnd(Package);						break;
		case EPackageType::CardMove:					HandleCardMove(Package);					break;
		case EPackageType::CardAttach:				HandleCardAttach(Package);					break;
		case EPackageType::CardAttack:					HandleCardAttack(Package);					break;
		case EPackageType::CardApplyDamage:	HandleCardApplyDamage(Package);		break;
		case EPackageType::CardActivate:				HandleCardActivate(Package);				break;
		case EPackageType::CardUpdate:				HandleCardUpdate(Package);				break;
		case EPackageType::CardApplyEffect:		HandleCardApplyEffect(Package);			break;
		case EPackageType::CardReveal:				HandleCardReveal(Package);					break;
		
		default : break;
	}
}

const FEventPackageStruct* UEventListener::FindPackageByIndex(int Index) const
{
	return PendingQueue.FindByPredicate([Index](const FEventPackageStruct& Package) {return Package.IsValid() && Package.GlobalEventIndex == Index;});
}

void UEventListener::Clear(int Index)
{
	check(LocalEventIndex == Index);	//确保回调与LocalEventIndex完全一致
	LocalEventIndex++;
	ProcessedQueue.Emplace(ProcessingPackage);
	PendingQueue.Remove(ProcessingPackage);
	PendingQueue.Shrink();
	ProcessingPackage = FEventPackageStruct();
}
//*************************************************************************

//****************************本地效果执行********************************
void UEventListener::HandleGameStart(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleGameEnd(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleTurnStart(const FEventPackageStruct& Package)
{
	Clear(Package.GlobalEventIndex);
}

void UEventListener::HandleTurnEnd(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardMove(const FEventPackageStruct& Package)
{
	if (Package.Params[0].CardOrPlayer.CardZone == EZone::HandZone && Package.Params[1].ZoneValue == EZone::DeckZone)
	{
		DrawCard(Package); return;
	}
	if (Package.Params[0].CardOrPlayer.CardZone == EZone::BoardZone && Package.Params[0].CardOrPlayer.CardType == EType::Servant &&
		Package.Params[1].ZoneValue == EZone::HandZone)
	{
		SummonServant(Package); return;
	}
	if (Package.Params[0].CardOrPlayer.CardZone == EZone::HandZone && Package.Params[0].CardOrPlayer.CardType == EType::Spell &&
		Package.Params[1].ZoneValue == EZone::DeckZone)
	{
		CastSpell(Package); return;
	}
}

void UEventListener::HandleCardAttach(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardAttack(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardApplyDamage(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardActivate(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardUpdate(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardApplyEffect(const FEventPackageStruct& Package)
{
	
}

void UEventListener::HandleCardReveal(const FEventPackageStruct& Package)
{

	
}
//****************************本地效果管理*********************************
void UEventListener::DrawCard(const FEventPackageStruct& Package)
{
	ACardModel* CardModel = CreateCardModel(Package.Params[0].CardOrPlayer);
	const bool Owning = Package.Params[0].CardOrPlayer.PlayerIndex == Controller -> PlayerState -> GetPlayerId();
	CardModel -> StartDrawCard(Owning, Package);
}

void UEventListener::SummonServant(const FEventPackageStruct& Package)
{
	ACardModel* CardModel =FindCardModel(Package.Params[0].CardOrPlayer.CardIndex);
	const bool Owning = Package.Params[0].CardOrPlayer.PlayerIndex == Controller -> PlayerState -> GetPlayerId();
	CardModel -> StartSummonServant(Owning, Package);
	Clear(Package.GlobalEventIndex);
}

void UEventListener::CastSpell(const FEventPackageStruct& Package)
{
	ACardModel* CardModel =FindCardModel(Package.Params[0].CardOrPlayer.CardIndex);
	const bool Owning = Package.Params[0].CardOrPlayer.PlayerIndex == Controller -> PlayerState -> GetPlayerId();
	Clear(Package.GlobalEventIndex);
}

ACardModel* UEventListener::CreateCardModel(const FCardStruct& CardStruct)
{
	//确定生成位置
	FTransform SpawnTransform;
	SpawnTransform.SetLocation(FVector::ZeroVector);
	SpawnTransform.SetRotation(FRotator::ZeroRotator.Quaternion());
	SpawnTransform.SetScale3D(FVector::OneVector);

	//生成卡牌
	ACardModel* NewCard = GetWorld() -> SpawnActor<ACardModel>(CardStruct.CardModelClass, SpawnTransform);
	NewCard -> CardStruct = CardStruct;
	NewCard -> EventListener = this;
	
	return NewCard ? NewCard : nullptr;
}

ACardModel* UEventListener::FindCardModel(const int CardIndex)
{
	return nullptr;
}
//*************************************************************************

//****************************分发卡牌更新********************************
void UEventListener::RefreshHandZone(const int PlayerIndex)
{
	if (Controller -> PlayerState -> GetPlayerId() == PlayerIndex)
	{
		for (ACardModel* CardModel : OwnerHandZone)
		{
			const int HandIndex = OwnerHandZone.IndexOfByPredicate([CardModel](const ACardModel* Idx) {return Idx && Idx == CardModel;});
			FVector Start = FVector(-400.f, 200.f, 200.f);
			FVector End = FVector(-400.f, 700.f, 220.f);

			const int AdjustedTotal = OwnerHandZone.Num() + 1;
			const int AdjustedIndex = HandIndex + 1;
	
			const float Alpha = OwnerHandZone.Num() == 1 ? 0.5f : static_cast<float>(AdjustedIndex) / static_cast<float>(AdjustedTotal);
			CardModel -> TargetLocation = FMath::Lerp(Start, End, Alpha);
		}
	}
	else
	{
		for (ACardModel* CardModel : EnemyHandZone)
		{
			const int HandIndex = EnemyHandZone.IndexOfByPredicate([CardModel](const ACardModel* Idx) {return Idx && Idx == CardModel;});
			FVector Start = FVector(500.f, -200.f, 200.f);
			FVector End = FVector(500.f, -700.f, 220.f);

			const int AdjustedTotal = EnemyHandZone.Num() + 1;
			const int AdjustedIndex = HandIndex + 1;
	
			const float Alpha = EnemyHandZone.Num() == 1 ? 0.5f : static_cast<float>(AdjustedIndex) / static_cast<float>(AdjustedTotal);
			CardModel -> TargetLocation = FMath::Lerp(Start, End, Alpha);
		}
	}
}

void UEventListener::RemoveFromHandZone(ACardModel* CardModel)
{
	if (bool Owning = CardModel -> CardStruct.PlayerIndex == Controller -> PlayerState -> GetPlayerId())
	{
		OwnerHandZone.Remove(CardModel);
	}
	else
	{
		EnemyHandZone.Remove(CardModel);
	}
}

void UEventListener::AddToHandZone(ACardModel* CardModel)
{
	if (bool Owning = CardModel -> CardStruct.PlayerIndex == Controller -> PlayerState -> GetPlayerId())
	{
		OwnerHandZone.Emplace(CardModel);
	}
	else
	{
		EnemyHandZone.Emplace(CardModel);
	}
}
//*************************************************************************
